# 📊 **E-commerce Retail Analysis**







📌 Project Overview

---

This project analyzes transactional data from an e-commerce retailer to uncover key business insights related to revenue, customer behavior, product performance, and return patterns.



The analysis follows an end-to-end approach:

* Data cleaning and preparation (SQL)
* KPI definition
* Exploratory data analysis
* Interactive dashboard development (Streamlit)



\-----



🎯 Business Questions

---

This analysis aims to answer the following:

* How does revenue evolve over time?
* Which countries and products drive most of the revenue?
* How is customer activity distributed?
* Are there anomalies in product returns?



\-----





##### 🧠 Key Insights



###### &#x09;**1. Revenue Trends**

&#x09;Revenue shows clear seasonal patterns, suggesting strong peaks during specific periods (likely holidays).



###### &#x09;**2. Product Performance**

&#x09;A small subset of products generates a large portion of total revenue.



###### &#x09;**3. Customer Behavior**

&#x09;Revenue is concentrated among a limited number of customers.



###### &#x09;**4. Return Analysis**

&#x09;Some products show return rates above 100%.



This anomaly is due to:

\- Returns occurring in a different time window than purchases

\- Dataset time limitations



\-----



#### 🗂️ Dataset



The dataset was cleaned to remove:

* Missing customer IDs
* Invalid transactions (zero or negative prices)
* Zero quantities



Returns (negative quantities) were preserved for analysis.



\-----



#### 🛠️ Tech Stack



* SQL (PostgreSQL)
* Python (Pandas)
* Streamlit
* Altair



\-----



#### 📊 Dashboard



The dashboard includes:

* Monthly revenue trend
* Top 10 countries by revenue
* Top 10 products by revenue
* Return rate analysis



\-----



##### 🌐 Live Demo







